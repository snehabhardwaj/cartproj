﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Model;

namespace WebApplication3
{
    public class shoppingContext : DbContext
    {
        public shoppingContext(DbContextOptions options) : base(options) { }


       
      

        public virtual DbSet<Table> Tables { get; set; }
    }
}
