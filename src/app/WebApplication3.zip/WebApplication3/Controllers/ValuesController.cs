﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Model;
using Microsoft.EntityFrameworkCore;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    public class ValuesController : Controller
    {
        shoppingContext _shoppingContext;

        public ValuesController(shoppingContext shoppingContext)
        {
            _shoppingContext = shoppingContext;
        }



        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var order = await _shoppingContext.Tables.Where(o => o.Id == 1).SingleOrDefaultAsync();
                return Ok(order);
               
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Something went wrong: {ex.Message}");
            }
        }


        [HttpPost]
        public async Task<IActionResult> Create([FromBody]Table inputModel)
        {
            if (inputModel == null)
                return BadRequest();

            var entity = new Table
            {
                item = inputModel.item,
                Description = inputModel.Description,

            };

            this._shoppingContext.Tables.Add(entity);
            await this._shoppingContext.SaveChangesAsync();

            var outputModel = new
            {
                entity.Id,
                entity.item,
                entity.Description,
                entity.price,
            };

            return Ok(outputModel);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]Table inputModel)
        {
            if (inputModel == null || id != inputModel.Id)
                return BadRequest();

            var entity = new Table
            {
                item = inputModel.item,
                Description = inputModel.Description,
            };

            this._shoppingContext.Tables.Update(entity);
            this._shoppingContext.SaveChanges();

            return NoContent();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var entity = _shoppingContext.Tables
                                .Where(e => e.Id == id)
                                .FirstOrDefault();

            if (entity == null)
                return NotFound();

            this._shoppingContext.Tables.Remove(entity);
            this._shoppingContext.SaveChanges();

            return NoContent();
        }
    }
}
